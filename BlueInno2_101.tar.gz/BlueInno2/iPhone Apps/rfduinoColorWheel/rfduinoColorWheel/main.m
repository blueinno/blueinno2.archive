//
//  main.m
//  rfduinoColorWheel
//
//  Created by Steve on 2/11/13.
//  Copyright (c) 2013 RF Digital. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
