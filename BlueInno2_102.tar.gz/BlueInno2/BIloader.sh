#!/bin/bash

_script="$(readlink -f ${BASH_SOURCE[0]})"
_base="$(dirname $_script)"

python $_base/hci_dfu_send_hex.py $1 $2 $3 $4 $5
